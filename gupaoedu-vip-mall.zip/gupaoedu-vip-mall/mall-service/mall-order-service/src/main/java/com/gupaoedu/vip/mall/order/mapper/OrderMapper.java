package com.gupaoedu.vip.mall.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.order.model.Order;

/*****
 * @Author:
 * @Description:
 ****/
public interface OrderMapper extends BaseMapper<Order> {
}
