package com.gupaoedu.vip.mall.goods.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.goods.model.Spu;

/*****
 * @Author: 波波
 * @Description: 云商城
 ****/
public interface SpuMapper extends BaseMapper<Spu> {
}
