package com.gupaoedu.vip.mall.seckill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.seckill.model.SeckillGoods;
import org.apache.ibatis.annotations.Update;

/*****
 * @Author:
 * @Description:
 ****/
public interface SeckillGoodsMapper extends BaseMapper<SeckillGoods> {

    
}
