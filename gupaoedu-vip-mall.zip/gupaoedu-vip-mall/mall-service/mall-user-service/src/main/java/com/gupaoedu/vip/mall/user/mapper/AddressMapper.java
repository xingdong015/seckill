package com.gupaoedu.vip.mall.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.user.model.Address;

/*****
 * @Author:
 * @Description:
 ****/
public interface AddressMapper extends BaseMapper<Address> {
}
